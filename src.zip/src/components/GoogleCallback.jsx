import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { handleGoogleCallback } from "../api/auth";

export default function GoogleCallback() {
  const navigate = useNavigate();
  const requested = useRef(false); // 중복 방지 플래그

  useEffect(() => {
    if (requested.current) return; // 이미 요청했으면 실행 안 함
    requested.current = true;

    const url = new URL(window.location.href);
    const code = url.searchParams.get("code");

    if (code) {
      handleGoogleCallback(code)
        .then((res) => {
          console.log("구글 로그인 응답:", res);
          // 토큰과 userId가 있으면 성공
          if (res && res.token && res.userId) {
            localStorage.setItem("token", res.token);
            localStorage.setItem("isAdmin", "0");
            localStorage.removeItem("helpModalHide"); // 구글 로그인 시 도움말 모달 다시 보이도록
            navigate("/main");
          } else {
            alert("구글 로그인 실패: 사용자 정보 없음");
            navigate("/");
          }
        })
        .catch((err) => {
          console.error("구글 로그인 에러:", err);
          alert("구글 로그인 실패");
          navigate("/");
        });
    }
  }, [navigate]);

  return <div>구글 로그인 중...</div>;
}
