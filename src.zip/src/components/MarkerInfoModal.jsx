import React, { useEffect, useState } from "react";
import { getMarkersByTypes, getReportsByTypes } from "../api/Map";

const BASE_URL = "http://localhost:8080/uploads/reportImgs/";

function getImageFileName(imagePath) {
  // '/reportImgs/파일명' 또는 'reportImgs/파일명'에서 파일명만 추출
  if (!imagePath) return '';
  const parts = imagePath.split("/");
  return parts[parts.length - 1];
}

function MarkerInfoModal({ mapInstanceRef, activeFacilityTypes }) {
  const [modalInfo, setModalInfo] = useState({ open: false, address: '', comment: '', imageUrl: '' });
  const [facilityMarkers, setFacilityMarkers] = useState([]);

  useEffect(() => {
    // 마커 생성 및 클릭 이벤트 등록
    if (!mapInstanceRef.current) return;
    // 기존 마커 제거
    facilityMarkers.forEach(marker => marker.setMap(null));
    const markerTypes = activeFacilityTypes.filter(t => [1,2,3,4].includes(t));
    const reportTypes = activeFacilityTypes.filter(t => [5,6,7].includes(t));
    let allMarkers = [];
    async function fetchAndShowMarkers() {
      // markers 테이블
      if (markerTypes.length > 0) {
        const markers = await getMarkersByTypes(markerTypes);
        if (Array.isArray(markers) && markers.length > 0) {
          const newMarkers = markers.map((m) => {
            const lat = Number(m.lat);
            const lng = Number(m.lon);
            const marker = new window.Tmapv2.Marker({
              position: new window.Tmapv2.LatLng(lat, lng),
              map: mapInstanceRef.current,
              title: m.name || m.desc1,
            //   icon: window.location.origin + (m.icon || "/markers/icon-pin.png"),
              iconSize: new window.Tmapv2.Size(54, 54),
            });
            marker.addListener('click', () => {
              setModalInfo({
                open: true,
                address: m.address || '',
                comment: m.comment || '',
                imageUrl: m.image ? getImageFileName(m.image) : ''
              });
            });
            marker.setMap(mapInstanceRef.current);
            return marker;
          });
          allMarkers = allMarkers.concat(newMarkers);
        }
      }
      // reports 테이블
      if (reportTypes.length > 0) {
        const reports = await getReportsByTypes(reportTypes);
        if (Array.isArray(reports) && reports.length > 0) {
          const newMarkers = reports.map((m) => {
            const lat = Number(m.lat);
            const lng = Number(m.lon);
            const marker = new window.Tmapv2.Marker({
              position: new window.Tmapv2.LatLng(lat, lng),
              map: mapInstanceRef.current,
              title: m.name || m.desc1,
            //   icon: window.location.origin + (m.icon || "/markers/icon-pin.png"),
              iconSize: new window.Tmapv2.Size(54, 54),
            });
            marker.addListener('click', () => {
              setModalInfo({
                open: true,
                address: m.address || '',
                comment: m.comment || '',
                imageUrl: m.image ? getImageFileName(m.image) : ''
              });
            });
            marker.setMap(mapInstanceRef.current);
            return marker;
          });
          allMarkers = allMarkers.concat(newMarkers);
        }
      }
      setFacilityMarkers(allMarkers);
    }
    fetchAndShowMarkers();
    // cleanup: 마커 제거
    return () => {
      allMarkers.forEach(marker => marker.setMap(null));
    };
    // eslint-disable-next-line
  }, [mapInstanceRef, activeFacilityTypes]);

  if (!modalInfo.open) return null;
  const hasInfo = (modalInfo.address && modalInfo.address.trim()) || (modalInfo.comment && modalInfo.comment.trim());
  return (
    <div style={{
      position: 'fixed', left: 0, top: 0, width: '100vw', height: '100vh',
      background: 'rgba(0,0,0,0.3)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center'
    }} onClick={() => setModalInfo({ ...modalInfo, open: false })}>
      <div style={{
        background: '#fff', borderRadius: 16, minWidth: 280, maxWidth: 340, padding: '32px 24px',
        boxShadow: '0 4px 24px rgba(0,0,0,0.12)', textAlign: 'center', position: 'relative'
      }} onClick={e => e.stopPropagation()}>
        <button onClick={() => setModalInfo({ ...modalInfo, open: false })} style={{position:'absolute',top:12,right:16,fontSize:20,background:'none',border:'none',cursor:'pointer'}}>×</button>
        {modalInfo.imageUrl && (
          <img src={`${BASE_URL}${modalInfo.imageUrl}`} alt="첨부 이미지" style={{ maxWidth: '100%', maxHeight: 180, borderRadius: 12, marginBottom: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.10)' }} />
        )}
        {hasInfo ? (
          <>
            {modalInfo.address && <div style={{fontWeight:'bold',fontSize:18,marginBottom:12}}>{modalInfo.address}</div>}
            {modalInfo.comment && <div style={{fontSize:16,color:'#555'}}>{modalInfo.comment}</div>}
          </>
        ) : (
          <div style={{fontSize:17,color:'#aaa'}}>정보없음</div>
        )}
      </div>
    </div>
  );
}

export default MarkerInfoModal; 