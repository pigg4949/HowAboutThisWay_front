package com.HATW.service;

import java.io.IOException;
import java.util.Map;

public interface MapService {
    String searchLocation(String keyword) throws IOException, InterruptedException;
    String attachCollisions(String transitJson, String responseJson) throws Exception;
//    String getTest(Map<String, Object> params) throws IOException;
}
