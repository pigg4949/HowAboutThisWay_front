package com.HATW.service;

import com.HATW.dto.ConnectorWalkDetailDTO;
import com.HATW.dto.MarkerDTO;
import com.HATW.mapper.MarkerMapper;
import com.HATW.mapper.ReportMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
@RequiredArgsConstructor
public class TransitServiceImpl implements TransitService {
    private final MarkerMapper markerMapper;
    private final TmapService tmapService;
    private final ReportMapper reportMapper;
    private final ObjectMapper mapper = new ObjectMapper();


    @Override
    public List<ConnectorWalkDetailDTO> computeWalkPath(String jsonData) throws Exception {
        JsonNode root = mapper.readTree(jsonData);
        ArrayNode itins = (ArrayNode) root.path("metaData").path("plan").path("itineraries");
        List<ConnectorWalkDetailDTO> details = new ArrayList<>();

        for (int itinIdx = 0; itinIdx < itins.size(); itinIdx++) {
            ArrayNode legs = (ArrayNode) itins.get(itinIdx).path("legs");

            // 1-1) 지하철 레그 인덱스 찾기
            int firstSub = -1, lastSub = -1;
            for (int i = 0; i < legs.size(); i++) {
                if ("SUBWAY".equalsIgnoreCase(legs.get(i).path("mode").asText())) {
                    if (firstSub < 0) firstSub = i;
                    lastSub = i;
                }
            }
            if (firstSub < 0) continue;

            // 1-2) 전·후 WALK 레그 인덱스 찾기
            int beforeWalk = -1, afterWalk = -1;
            for (int i = firstSub - 1; i >= 0; i--) {
                if ("WALK".equalsIgnoreCase(legs.get(i).path("mode").asText())) {
                    beforeWalk = i;
                    break;
                }
            }
            for (int i = lastSub + 1; i < legs.size(); i++) {
                if ("WALK".equalsIgnoreCase(legs.get(i).path("mode").asText())) {
                    afterWalk = i;
                    break;
                }
            }
            if (beforeWalk < 0 || afterWalk < 0) continue;

            // 1-2.5) 지하철↔지하철 스킵
            String prevTransit = legs.get(firstSub).path("mode").asText();
            String nextTransit = legs.get(lastSub).path("mode").asText();
            if ("SUBWAY".equalsIgnoreCase(prevTransit) && "SUBWAY".equalsIgnoreCase(nextTransit)) {
                continue;
            }

            // 1-3) connector 시작/끝 좌표
            ObjectNode bwLeg = (ObjectNode) legs.get(beforeWalk);
            double bwEndLon = bwLeg.path("end").path("lon").asDouble();
            double bwEndLat = bwLeg.path("end").path("lat").asDouble();

            ObjectNode awLeg = (ObjectNode) legs.get(afterWalk);
            double awStartLon = awLeg.path("start").path("lon").asDouble();
            double awStartLat = awLeg.path("start").path("lat").asDouble();

            // 1-4) 역 이름 추출
            String fsName = legs.get(firstSub)
                    .path("passStopList").path("stationList").get(0)
                    .path("stationName").asText();
            JsonNode lsList = legs.get(lastSub).path("passStopList").path("stationList");
            String lsName = lsList.get(lsList.size() - 1).path("stationName").asText();

            // 1-5) DB에서 엘리베이터 후보 조회
            List<MarkerDTO> fsCands = markerMapper.selectByStationName(fsName);
            if (fsCands.isEmpty()) fsCands = markerMapper.selectByStationName(fsName + "역");
            List<MarkerDTO> lsCands = markerMapper.selectByStationName(lsName);
            if (lsCands.isEmpty()) lsCands = markerMapper.selectByStationName(lsName + "역");

            // 1-6) 최적 좌표 탐색
            double bestBeforeX = 0, bestBeforeY = 0;
            int bestBeforeDist = Integer.MAX_VALUE;
            for (MarkerDTO cand : fsCands) {
                Map<String,Object> p = new HashMap<>();
                p.put("startX", bwEndLon);
                p.put("startY", bwEndLat);
                p.put("endX",   cand.getLon());
                p.put("endY",   cand.getLat());
                p.put("startName", fsName + "역 앞");
                p.put("endName",   fsName + " 엘리베이터");
                p.put("searchOption", 30);
                String j = tmapService.getPedestrianRoute(p);
                int d = mapper.readTree(j)
                        .path("features").get(0)
                        .path("properties").path("totalDistance").asInt(Integer.MAX_VALUE);
                if (d < bestBeforeDist) {
                    bestBeforeDist = d;
                    bestBeforeX = cand.getLon();
                    bestBeforeY = cand.getLat();
                }
            }
            double bestAfterX = 0, bestAfterY = 0;
            int bestAfterDist = Integer.MAX_VALUE;
            for (MarkerDTO cand : lsCands) {
                Map<String,Object> p = new HashMap<>();
                p.put("startX", cand.getLon());
                p.put("startY", cand.getLat());
                p.put("endX",   awStartLon);
                p.put("endY",   awStartLat);
                p.put("startName", lsName + " 엘리베이터");
                p.put("endName",   lsName + "역 뒤");
                p.put("searchOption", 30);
                String j = tmapService.getPedestrianRoute(p);
                int d = mapper.readTree(j)
                        .path("features").get(0)
                        .path("properties").path("totalDistance").asInt(Integer.MAX_VALUE);
                if (d < bestAfterDist) {
                    bestAfterDist = d;
                    bestAfterX = cand.getLon();
                    bestAfterY = cand.getLat();
                }
            }

            // 1-7) passList 생성
            String passList = bestBeforeX + "," + bestBeforeY + ";" + bestAfterX + "," + bestAfterY;

            // 1-8) DTO 추가
            details.add(new ConnectorWalkDetailDTO(
                    itinIdx,
                    beforeWalk,
                    afterWalk,
                    bwEndLon,
                    bwEndLat,
                    awStartLon,
                    awStartLat,
                    30,
                    passList
            ));
        }

        return details;
    }



    @Override
    public String connectingTrafficWalkPaths(String transitJson) throws Exception {
        List<ConnectorWalkDetailDTO> connectors = computeWalkPath(transitJson);

        ObjectNode root = (ObjectNode) mapper.readTree(transitJson);
        ArrayNode itineraries = (ArrayNode) root
                .path("metaData").path("plan").path("itineraries");

        for (ConnectorWalkDetailDTO dto : connectors) {
            int iti = dto.getItineraryIndex();
            int bw  = dto.getBeforeWalkLegIndex();
            int aw  = dto.getAfterWalkLegIndex();
            ObjectNode itin = (ObjectNode) itineraries.get(iti);
            ArrayNode legs  = (ArrayNode) itin.path("legs");

            // 시작/끝 레그 이름 추출
            ObjectNode bwLegNode = (ObjectNode) legs.get(bw);
            String bwLegStartName = bwLegNode.path("start").path("name").asText("");
            ObjectNode awLegNode = (ObjectNode) legs.get(aw);
            String awLegEndName   = awLegNode.path("end").path("name").asText("");

            // passList 한 번 호출 → fullRoute
            Map<String,Object> params = new HashMap<>();
            params.put("startX",       dto.getStartX());
            params.put("startY",       dto.getStartY());
            params.put("endX",         dto.getEndX());
            params.put("endY",         dto.getEndY());
            params.put("startName",    bwLegStartName);
            params.put("endName",      awLegEndName);
            params.put("searchOption", dto.getSearchOption());
            params.put("passList",     dto.getPassList());

            try {
                String fullJson = tmapService.getPedestrianRoute(params);
                ObjectNode fullRoute = (ObjectNode) mapper.readTree(fullJson);

                // 3개 섹션으로 분할
                List<ObjectNode> parts = splitBySection(fullRoute);

                // before(0)·after(2) 섹션만 덮어쓰기
                ((ObjectNode) legs.get(bw)).set("walkRouteJson", parts.get(0));
                ((ObjectNode) legs.get(aw)).set("walkRouteJson", parts.get(2));
            } catch (IOException e) {
                System.err.println("[WARN] connector passList failed (iti=" + iti + "): " + e.getMessage());
            }

            // 나머지 WALK 레그는 기존대로 개별 호출 (기존 로직 유지)
            for (int j = 0; j < legs.size(); j++) {
                if (j == bw || j == aw) continue;
                ObjectNode leg = (ObjectNode) legs.get(j);
                if (!"WALK".equalsIgnoreCase(leg.path("mode").asText())) continue;

                double sx = leg.path("start").path("lon").asDouble();
                double sy = leg.path("start").path("lat").asDouble();
                double ex = leg.path("end").path("lon").asDouble();
                double ey = leg.path("end").path("lat").asDouble();
                String sName = leg.path("start").path("name").asText("");
                String eName = leg.path("end").path("name").asText("");

                try {
                    Map<String,Object> p = new HashMap<>();
                    p.put("startX",    sx);
                    p.put("startY",    sy);
                    p.put("endX",      ex);
                    p.put("endY",      ey);
                    p.put("startName", sName);
                    p.put("endName",   eName);
                    p.put("searchOption", 30);
                    String walkJson = tmapService.getPedestrianRoute(p);
                    leg.set("walkRouteJson", mapper.readTree(walkJson));
                } catch (IOException ioe) {
                    System.err.println("[WARN] pedestrian API failed at leg " + j + ": " + ioe.getMessage());
                }
            }

            // 전체 distance/time 재계산
            int totalDist = 0, totalTime = 0;
            int totalWalkDist = 0, totalWalkTime = 0;
            for (JsonNode ln : legs) {
                ObjectNode leg = (ObjectNode) ln;
                String mode = leg.path("mode").asText();
                JsonNode wj = leg.path("walkRouteJson");
                int d, t;
                if (wj.isObject()) {
                    d = 0; t = 0;
                    for (JsonNode feat : wj.path("features")) {
                        JsonNode props = feat.path("properties");
                        if (props.has("distance")) d += props.get("distance").asInt();
                        if (props.has("time"))     t += props.get("time").asInt();
                    }
                    leg.put("distance",    d);
                    leg.put("sectionTime", t);
                } else {
                    d = leg.path("distance").asInt(0);
                    t = leg.path("sectionTime").asInt(0);
                }
                totalDist  += d;
                totalTime  += t;
                if ("WALK".equalsIgnoreCase(mode)) {
                    totalWalkDist += d;
                    totalWalkTime += t;
                }
            }
            itin.put("totalDistance",     totalDist);
            itin.put("totalTime",         totalTime);
            itin.put("totalWalkDistance", totalWalkDist);
            itin.put("totalWalkTime",     totalWalkTime);
        }

        return mapper.writeValueAsString(root);
    }

    /**
     * fullRoute.features[].properties.section 값을 보고
     * 1,2,3 섹션별 FeatureCollection 을 0,1,2 순서로 잘라 반환
     */
    private List<ObjectNode> splitBySection(ObjectNode fullRoute) {
        ArrayNode features = (ArrayNode) fullRoute.path("features");
        Map<Integer, ArrayNode> sectionMap = new TreeMap<>();
        for (JsonNode f : features) {
            int sec = f.path("properties").path("section").asInt(1);
            sectionMap.computeIfAbsent(sec, k -> mapper.createArrayNode()).add(f);
        }
        List<ObjectNode> parts = new ArrayList<>();
        for (ArrayNode arr : sectionMap.values()) {
            ObjectNode part = mapper.createObjectNode();
            part.set("type",     fullRoute.get("type"));
            part.set("bbox",     fullRoute.get("bbox"));
            part.set("features", arr);
            parts.add(part);
        }
        return parts;
    }


    // 노약자 임산부용 함수
    // (1) helper: 이 레그가 BUS 또는 SUBWAY 인지 판별
    private boolean isTransitLeg(JsonNode leg) {
        String mode = leg.path("mode").asText();
        return "BUS".equalsIgnoreCase(mode) || "SUBWAY".equalsIgnoreCase(mode);
    }

    @Override
    public String connectingAllWalkPaths(String transitJson) throws Exception {
        ObjectNode root = (ObjectNode) mapper.readTree(transitJson);
        ArrayNode itineraries = (ArrayNode) root
                .path("metaData")
                .path("plan")
                .path("itineraries");

        for (JsonNode itinNode : itineraries) {
            ObjectNode itin = (ObjectNode) itinNode;
            ArrayNode legs = (ArrayNode) itin.path("legs");

            for (int i = 0; i < legs.size(); i++) {
                ObjectNode leg = (ObjectNode) legs.get(i);
                if (!"WALK".equalsIgnoreCase(leg.path("mode").asText())) {
                    continue;
                }

                double sx = leg.path("start").path("lon").asDouble();
                double sy = leg.path("start").path("lat").asDouble();
                double ex = leg.path("end").path("lon").asDouble();
                double ey = leg.path("end").path("lat").asDouble();
                String sName = leg.path("start").path("name").asText("");
                String eName = leg.path("end").path("name").asText("");

                // 1) 출발=도착(0m) 또는 너무 근거리면 호출 생략
                if (Double.compare(sx, ex) == 0 && Double.compare(sy, ey) == 0) {
                    continue;
                }

                // 2) passList 만들기
                String passList = null;
                if (i > 0 && "BUS".equalsIgnoreCase(legs.get(i-1).path("mode").asText())) {
                    passList = buildPassList((ObjectNode) legs.get(i-1).path("passStopList"));
                } else if (i + 1 < legs.size() && "BUS".equalsIgnoreCase(legs.get(i+1).path("mode").asText())) {
                    passList = buildPassList((ObjectNode) legs.get(i+1).path("passStopList"));
                }

                try {
                    Map<String,Object> params = new HashMap<>();
                    params.put("startX",       sx);
                    params.put("startY",       sy);
                    params.put("endX",         ex);
                    params.put("endY",         ey);
                    params.put("startName",    sName);       // 필수
                    params.put("endName",      eName);       // 필수
                    params.put("searchOption", 30);          // 최단+계단회피
                    if (passList != null) {
                        params.put("passList", passList);
                    }

                    String walkJson = tmapService.getPedestrianRoute(params);
                    leg.set("walkRouteJson", mapper.readTree(walkJson));
                } catch (IOException ioe) {
                    System.err.println("[WARN] pedestrian API error at leg " + i + ": " + ioe.getMessage());
                }
            }

            // --- 기존 로직 그대로 거리/시간 재계산 ---
            int totalDist      = 0;
            int totalTime      = 0;
            int totalWalkDist  = 0;
            int totalWalkTime  = 0;

            for (JsonNode legNode : legs) {
                ObjectNode leg = (ObjectNode) legNode;
                String mode = leg.path("mode").asText();

                int dist, time;
                JsonNode wj = leg.path("walkRouteJson");
                if (wj.isObject()) {
                    dist = 0; time = 0;
                    for (JsonNode feat : wj.path("features")) {
                        JsonNode p = feat.path("properties");
                        if (p.has("distance")) dist += p.get("distance").asInt();
                        if (p.has("time"))     time += p.get("time").asInt();
                    }
                    leg.put("distance",    dist);
                    leg.put("sectionTime", time);
                } else {
                    dist = leg.path("distance").asInt(0);
                    time = leg.path("sectionTime").asInt(0);
                }

                totalDist += dist;
                totalTime += time;
                if ("WALK".equalsIgnoreCase(mode)) {
                    totalWalkDist  += dist;
                    totalWalkTime  += time;
                }
            }

            itin.put("totalDistance",     totalDist);
            itin.put("totalTime",         totalTime);
            itin.put("totalWalkDistance", totalWalkDist);
            itin.put("totalWalkTime",     totalWalkTime);
        }

        return mapper.writeValueAsString(root);
    }

    /** BUS passStopList 에서 "lon,lat;lon,lat;..." 형태로 합쳐 반환 */
    private String buildPassList(ObjectNode passStopList) {
        ArrayNode stations = (ArrayNode) passStopList.path("stationList");
        List<String> points = new ArrayList<>();
        for (JsonNode s : stations) {
            points.add(s.path("lon").asText() + "," + s.path("lat").asText());
        }
        return String.join(";", points);
    }

}