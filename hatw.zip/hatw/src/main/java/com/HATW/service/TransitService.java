package com.HATW.service;

import com.HATW.dto.ConnectorWalkDetailDTO;

import java.io.IOException;
import java.util.List;

public interface TransitService {
    /**
     * 원본 대중교통 JSON 에서,
     * 각 itinerary 별로 앞/뒤 WALK 레그의 보행자 API 최단+계단회피 경로만 뽑아낸 정보를 리턴
     */
    List<ConnectorWalkDetailDTO> computeWalkPath(String jsonData) throws Exception;

    /**
     * 원본 대중교통 JSON 에 computeConnectorWalkDetails 결과를 덮어쓴 새로운 JSON 반환
     */
    String connectingTrafficWalkPaths(String transitJson) throws Exception;

    String connectingAllWalkPaths(String transitJson) throws Exception;

}
