package com.HATW.service;


import com.HATW.dto.ConnectorWalkDetailDTO;
import com.HATW.dto.ReportDTO;
import com.HATW.mapper.ReportMapper;
import com.HATW.util.GeometryUtil;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;

@Service
@RequiredArgsConstructor
public class MapServiceImpl implements MapService {

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final TransitService transitService;
    private final ReportMapper reportMapper;
    private final Gson gson = new Gson();

    @Value("${POI.URL}")
    private String poiUrl;
    @Value("${TMAP.APP.KEY}")
    private String appKey;

    @Override
    public String searchLocation(String keyword) throws IOException, InterruptedException {
        String encoded = URLEncoder.encode(keyword, StandardCharsets.UTF_8);
        String uri = String.format(
                "%s?version=1&format=json&appKey=%s&searchKeyword=%s&searchType=all&page=1&count=10&reqCoordType=WGS84GEO&resCoordType=EPSG3857",
                poiUrl, appKey, encoded
        );
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .header("Accept", "application/json")
                .GET()
                .build();
        HttpResponse<String> res = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) {
            throw new IOException("POI 검색 API 에러(status=" + res.statusCode() + "): " + res.body());
        }
        return res.body();
    }

    /**
     * JSON 안의 전체 경로를 바탕으로
     * report 테이블의 좌표/코멘트를 비교‧추가하여
     * "collisions" 배열을 붙인 최종 JSON을 리턴
     */
    @Override
    public String attachCollisions(String transitJson, String responseJson) throws Exception {
        // 1) 원본 대중교통 JSON 파싱
        JsonObject transitObj = gson.fromJson(transitJson, JsonObject.class);
        JsonObject planObj = transitObj.has("plan") && transitObj.get("plan").isJsonObject()
                ? transitObj.getAsJsonObject("plan")
                : null;
        JsonArray itineraries = new JsonArray();
        if (planObj != null && planObj.has("itineraries") && planObj.get("itineraries").isJsonArray()) {
            itineraries = planObj.getAsJsonArray("itineraries");
        }

        // 2) 응답 JSON 파싱 (여기에 collisions를 붙임)
        JsonObject respObj = gson.fromJson(responseJson, JsonObject.class);

        // 3) DB에서 리포트 전부 조회
        List<ReportDTO> reports = reportMapper.findApprovedReports();
        List<ReportDTO> collisions = new ArrayList<>();

        for (ReportDTO rpt : reports) {
            double lon = rpt.getLon(), lat = rpt.getLat();
            boolean hit = false;

            // 4‑a) 대중교통 경로(itineraries) 검사
            outer:
            for (JsonElement itinEl : itineraries) {
                JsonArray legs = itinEl.getAsJsonObject()
                        .getAsJsonArray("legs");
                for (JsonElement legEl : legs) {
                    JsonObject leg = legEl.getAsJsonObject();
                    // steps.linestring
                    if (leg.has("steps")) {
                        for (JsonElement stepEl : leg.getAsJsonArray("steps")) {
                            String ls = stepEl.getAsJsonObject().get("linestring").getAsString();
                            if (GeometryUtil.isPointOnLinestring(ls, lon, lat)) {
                                hit = true;
                                break outer;
                            }
                        }
                    }
                    // passShape.linestring
                    if (leg.has("passShape")) {
                        String ls = leg.getAsJsonObject("passShape").get("linestring").getAsString();
                        if (GeometryUtil.isPointOnLinestring(ls, lon, lat)) {
                            hit = true;
                            break outer;
                        }
                    }
                }
            }

            // 4‑b) 보행 GeoJSON 검사 (plan이 없거나, transit 검사에서 못 찾았으면)
            if (!hit) {
                Boolean geoHit = GeometryUtil.isPointOnGeoJsonLine(responseJson, lon, lat);
                hit = Boolean.TRUE.equals(geoHit);
            }

            if (hit) {
                collisions.add(new ReportDTO(lon, lat, rpt.getComment()));
            }
        }

        // 5) collisions 배열로 만들어 응답에 추가
        JsonArray collArr = new JsonArray();
        for (ReportDTO c : collisions) {
            JsonObject o = new JsonObject();
            o.addProperty("lon", c.getLon());
            o.addProperty("lat", c.getLat());
            o.addProperty("comment", c.getComment());
            collArr.add(o);
        }
        respObj.add("collisions", collArr);
        return gson.toJson(respObj);
    }


//    @Override
//    public String getTest(Map<String, Object> params) throws IOException {
//        // 1) 원본 JSON 로딩
//        String testFile = (String) params.get("testFile");
//        Resource res;
//        if (testFile != null) {
//            Path p = Path.of(testFile);
//            if (p.isAbsolute()) {
//                res = new FileSystemResource(p);
//                System.out.println("[DEBUG] Reading test JSON from absolute path: " + testFile);
//            } else {
//                res = new ClassPathResource("data/" + testFile);
//                System.out.println("[DEBUG] Reading test JSON from classpath: data/" + testFile);
//            }
//        } else {
//            res = new ClassPathResource("data/transit_route_대치4동주민센터_to_반포종합운동장_2025-06-25T06-28-36-447Z.json");
//            System.out.println("[DEBUG] No testFile param, using default JSON");
//        }
//        if (!res.exists() || !res.isReadable()) {
//            throw new IOException("테스트용 대중교통 JSON 파일을 찾을 수 없습니다: " + res.getDescription());
//        }
//
//        String content;
//        try (InputStream is = res.getInputStream()) {
//            content = new String(is.readAllBytes(), StandardCharsets.UTF_8);
//            System.out.println("[DEBUG] Loaded JSON length: " + content.length());
//        }
//
//        // 2) computeConnectorWalkDetails 로 보행 세그먼트 정보 추출
//        try {
//            List<ConnectorWalkDetailDTO> details = transitService.computeWalkPath(content);
//            System.out.println("[DEBUG] Computed " + details.size() + " connector walk details");
//        } catch (Exception e) {
//            System.err.println("[ERROR] computeConnectorWalkDetails failed:");
//            e.printStackTrace(System.err);
//            // 필요에 따라 fallback 로직을 추가할 수 있습니다.
//        }
//
//        // 3) enrichTransitJsonWithWalkRoutes 호출 → 최종 가공된 JSON 반환
//        String enriched = content;
//        try {
//            enriched = transitService.connectingTrafficWalkPaths(content);
//            System.out.println("[DEBUG] Enriched JSON length: " + enriched.length());
//        } catch (Exception e) {
//            System.err.println("[ERROR] enrichTransitJsonWithWalkRoutes failed:");
//            e.printStackTrace(System.err);
//            // 여기서 원본 반환 혹은 예외 재발생 선택 가능
//            // throw new IOException("Failed to enrich transit JSON with walk routes", e);
//        }
//
//        // 4) 결과 반환
//        return enriched;
//    }

}