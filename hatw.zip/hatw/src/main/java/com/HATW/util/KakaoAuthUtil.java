package com.HATW.util;

public class KakaoAuthUtil {
    public static final String CLIENT_ID = "dc65abb4b12a5d1c1632d37d84d1ac71";
    public static final String  REDIRECT_URI = "http://localhost:5173/kakao-callback";
    public static final String TOKEN_URL = "https://kauth.kakao.com/oauth/token";
    public static final String USERINFO_URL = "https://kapi.kakao.com/v2/user/me";
}