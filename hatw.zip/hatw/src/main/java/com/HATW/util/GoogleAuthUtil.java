package com.HATW.util;

public class GoogleAuthUtil {
    public static final String CLIENT_ID     = "986385424479-823jtt1pk037afk7obm3rnnesfo26ik3.apps.googleusercontent.com";
    public static final String CLIENT_SECRET = "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";
    public static final String REDIRECT_URI  = "http://localhost:5173/google-callback";
    public static final String AUTH_URL      = "https://accounts.google.com/o/oauth2/v2/auth";
    public static final String TOKEN_URL     = "https://oauth2.googleapis.com/token";
    public static final String USERINFO_URL  = "https://www.googleapis.com/oauth2/v2/userinfo";
}
