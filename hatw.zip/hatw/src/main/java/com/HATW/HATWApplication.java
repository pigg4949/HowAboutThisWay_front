package com.HATW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HATWApplication {

    public static void main(String[] args) {
        SpringApplication.run(HATWApplication.class, args);
    }

}
