package com.HATW.dto;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class ConnectorWalkDetailDTO {
    private final int itineraryIndex;
    private final int beforeWalkLegIndex;
    private final int afterWalkLegIndex;
    // -- for full-route passList 호출에 쓰일 정보
    private final double startX;
    private final double startY;
    private final double endX;
    private final double endY;
    private final int    searchOption;
    private final String passList;  // "lon1,lat1;lon2,lat2;…"
}
